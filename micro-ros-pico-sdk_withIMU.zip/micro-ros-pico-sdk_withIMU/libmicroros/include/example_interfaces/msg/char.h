// generated from rosidl_generator_c/resource/idl.h.em
// with input from example_interfaces:msg/Char.idl
// generated code does not contain a copyright notice

#ifndef EXAMPLE_INTERFACES__MSG__CHAR_H_
#define EXAMPLE_INTERFACES__MSG__CHAR_H_

#include "example_interfaces/msg/detail/char__struct.h"
#include "example_interfaces/msg/detail/char__functions.h"
#include "example_interfaces/msg/detail/char__type_support.h"

#endif  // EXAMPLE_INTERFACES__MSG__CHAR_H_
