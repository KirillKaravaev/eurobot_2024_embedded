// generated from rosidl_generator_c/resource/idl.h.em
// with input from composition_interfaces:srv/LoadNode.idl
// generated code does not contain a copyright notice

#ifndef COMPOSITION_INTERFACES__SRV__LOAD_NODE_H_
#define COMPOSITION_INTERFACES__SRV__LOAD_NODE_H_

#include "composition_interfaces/srv/detail/load_node__struct.h"
#include "composition_interfaces/srv/detail/load_node__functions.h"
#include "composition_interfaces/srv/detail/load_node__type_support.h"

#endif  // COMPOSITION_INTERFACES__SRV__LOAD_NODE_H_
