// generated from rosidl_generator_c/resource/idl.h.em
// with input from rcl_interfaces:msg/ParameterDescriptor.idl
// generated code does not contain a copyright notice

#ifndef RCL_INTERFACES__MSG__PARAMETER_DESCRIPTOR_H_
#define RCL_INTERFACES__MSG__PARAMETER_DESCRIPTOR_H_

#include "rcl_interfaces/msg/detail/parameter_descriptor__struct.h"
#include "rcl_interfaces/msg/detail/parameter_descriptor__functions.h"
#include "rcl_interfaces/msg/detail/parameter_descriptor__type_support.h"

#endif  // RCL_INTERFACES__MSG__PARAMETER_DESCRIPTOR_H_
